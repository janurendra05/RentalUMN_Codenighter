<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Web extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('form');
    }

    public function user()
    {   
        if($this->session->userdata('email')==null){
            $tmplogin=[
                    'email' => "abc@yahoo.com",
                    'nama' => "abc",
                    'role_id' => 2,
                    'alamat' => "Jalan-jalan nomor 2",
                    'nomorTelepon' => "123456789"
                ];

                $this->session->set_userdata($tmplogin);
        }
        $data                          = array();
        $data['all_featured_products'] = $this->web_model->get_all_featured_product();
        $data['all_new_products']      = $this->web_model->get_all_new_product();
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/user',$data);
        $this->load->view('web/inc/bottom');
    }

    public function product()
    {
        $this->load->library('pagination');

        $config['base_url'] = base_url('web/product');
        $config['total_rows'] = $this->db->get('tbl_product')->num_rows();
        $config['per_page'] = 8;
        $config['num_links'] = 2;
        $config['full_tag_open'] = '<ul>';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['prev_link'] = '&lt; Previous';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['last_link'] = false;
        $config['next_link'] = 'Next &gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';

        $this->pagination->initialize($config);

        $data                    = array();
        $data['get_all_product'] = $this->web_model->get_all_product_pagi($config['per_page'], $this->uri->segment('3'));
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/product', $data);
        $this->load->view('web/inc/bottom');
    }

    public function single($id)
    {
        $data                       = array();
        $data['get_single_product'] = $this->web_model->get_single_product($id);
        $data['get_all_category']   = $this->web_model->get_all_category();
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/single', $data);
        $this->load->view('web/inc/bottom');
    }

    public function error()
    {
        $data = array();
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/error');
        $this->load->view('web/inc/bottom');
    }

    public function category_post($id)
    {
        $data                    = array();
        $data['get_all_product'] = $this->web_model->get_all_product_by_cat($id);
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/product', $data);
        $this->load->view('web/inc/bottom');
    }

    public function save_cart()
    {   
        if($this->session->userdata('email')=="abc@yahoo.com"){
            redirect('auth/login');
        }
        if ($this->session->has_userdata('email')) {
            $data       = array();
            $product_id = $this->input->post('product_id');
            $results    = $this->web_model->get_product_by_id($product_id);

            $data['id']      = $results->product_id;
            $data['name']    = $results->product_title;
            $data['price']   = $results->product_price;
            $data['qty']     = $this->input->post('qty');
            $data['options'] = array('product_image' => $results->product_image);

            $this->cart->insert($data);
            redirect('cart');
        } else {
            redirect('auth/login');
        }
    }

    public function order_list(){
        $data       = array();
        $user = $this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
        $data['orderlist']    = $this->web_model->get_all_order_id($user['id']);
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $data['title'] = 'Shop';

        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/orders',$data);
        $this->load->view('web/inc/bottom');
    }

    public function update_cart()
    {
        $data          = array();
        $data['qty']   = $this->input->post('qty');
        $data['rowid'] = $this->input->post('rowid');

        $this->cart->update($data);
        redirect('cart');
    }

    public function remove_cart()
    {

        $data = $this->input->post('rowid');
        $this->cart->remove($data);
        redirect('cart');
    }



    public function user_form()
    {
        if ($this->session->has_userdata('email')) {
        $data = array();
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/user_form');
        $this->load->view('web/inc/bottom');

        $this->cart->destroy();
        } else {
            redirect('/auth/login');
        }
    }

    public function checkout()
    {
        $data = array();
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/checkout');
        $this->load->view('web/inc/bottom');
    }

    public function save_order()
    {
        $data['payment_type'] = 'Cash on Delivery';

        $user = $this->db->get_where('user', ['email'=>$this->session->userdata('email')])->row_array();
        $payment_id           = 1;
        $odata                = array();
        $odata['customer_id'] = $user['id'];
        $odata['payment_id']  = $payment_id;
        $tax                  = ($this->cart->total() * 15) / 100;
        $odata['order_total'] = $tax + $this->cart->total();

        $order_id = $this->web_model->save_order_info($odata);

        $oddata = array();

        $myoddata = $this->cart->contents();

        if (!empty($myoddata)) {
            foreach ($myoddata as $oddatas) {
                $oddata['order_id']               = $order_id;
                $oddata['product_id']             = $oddatas['id'];
                $oddata['product_name']           = $oddatas['name'];
                $oddata['product_price']          = $oddatas['price'];
                $oddata['product_sales_quantity'] = $oddatas['qty'];
                $oddata['product_image']          = $oddatas['options']['product_image'];
                $this->web_model->save_order_details_info($oddata, $oddatas['id']);
            }

            $this->cart->destroy();

            redirect('/user_form');
        } else {
            redirect('/product');
            $this->session->set_flashdata('alert', '<div class="alert alert-warning" role="alert"> Empty Cart </div>');
        }
    }

    public function cart()
    {
        $data                  = array();
        $data['cart_contents'] = $this->cart->contents();
        $data['title'] = 'Shop';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('web/inc/sideU',$data);
        $this->load->view('web/inc/top',$data);
        $this->load->view('web/pages/cart', $data);
        $this->load->view('web/inc/bottom');
    }

    public function admin()
    {
        $data                          = array();
        $data['all_featured_products'] = $this->web_model->get_all_featured_product();
        $data['all_new_products']      = $this->web_model->get_all_new_product();

        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

        $data2['products'] = $this->db->get('tbl_product')->result_array();

        $this->load->view('web/inc/sideA',$data);
        $this->load->view('web/inc/topA',$data);
        $this->load->view('web/pages/productsA',$data2);
        $this->load->view('web/inc/bottom');
    }

    public function addP()
    {
        $data                          = array();
        $data['all_featured_products'] = $this->web_model->get_all_featured_product();
        $data['all_new_products']      = $this->web_model->get_all_new_product();

        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

        $data2['title2'] = 'Add';

        $this->load->view('web/inc/sideA',$data);
        $this->load->view('web/inc/topA',$data);
        $this->load->view('web/pages/crudAdmin', $data2);
        $this->load->view('web/inc/bottom');
    }
    public function addedP()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');
        $this->form_validation->set_rules('quantity', 'Quantity', 'required|numeric');
        $this->form_validation->set_rules('feature', 'Feature', 'required|numeric');
        $this->form_validation->set_rules('category', 'Category', 'required|numeric');
        $this->form_validation->set_rules('sDesc', 'SDesc', 'required');
        $this->form_validation->set_rules('lDesc', 'LDesc', 'required');

        if($this->form_validation->run() == false)
        {
                $data                          = array();
                $data['all_featured_products'] = $this->web_model->get_all_featured_product();
                $data['all_new_products']      = $this->web_model->get_all_new_product();

                $data['title'] = 'Admin';
                $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

                $data2['title2'] = 'Add';
                $data2['hidden'] = 'hidden';

                $this->load->view('web/inc/sideA',$data);
                $this->load->view('web/inc/topA',$data);
                $this->load->view('web/pages/crudAdmin', $data2);
                $this->load->view('web/inc/bottom');

        }else{

            $config = [
                'upload_path' => './uploads/',
                'allowed_types' => 'gif|jpg|png'
            ];

            $this->load->library('upload');
            $this->upload->initialize($config);

            if ($this->upload->do_upload('userfile'))
            {
                $image = $this->upload->data('file_name');
            }

            $data = [
                'product_title' => htmlspecialchars($this->input->post('name', true)),
                'product_short_description' => htmlspecialchars($this->input->post('sDesc', true)),
                'product_long_description' => htmlspecialchars($this->input->post('lDesc', true)),
                'product_image' => $image,
                'product_price' => htmlspecialchars($this->input->post('price', true)),
                'product_quantity' => htmlspecialchars($this->input->post('quantity', true)),
                'product_feature' => htmlspecialchars($this->input->post('feature', true)),
                'product_category' => htmlspecialchars($this->input->post('category', true))
            ];

            $this->db->insert('tbl_product', $data);
            $this->session->set_flashdata('alert', '<div class="alert alert-success" role="alert"> Produk telah berhasil ditambahkan </div>');
            redirect('web/admin');
        }
    }

    public function editP($id)
    {
        $data                          = array();
        $data['all_featured_products'] = $this->web_model->get_all_featured_product();
        $data['all_new_products']      = $this->web_model->get_all_new_product();

        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

        $data2['title2'] = 'Edit';
        $data2['p'] = $this->db->get_where('tbl_product',['product_id' => $id])->row_array();
        

        $this->load->view('web/inc/sideA',$data);
        $this->load->view('web/inc/topA',$data);
        $this->load->view('web/pages/crudAdminE', $data2);
        $this->load->view('web/inc/bottom');
    }
    public function editedP()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required|numeric');
        $this->form_validation->set_rules('quantity', 'Quantity', 'required|numeric');
        $this->form_validation->set_rules('feature', 'Feature', 'required|numeric');
        $this->form_validation->set_rules('category', 'Category', 'required|numeric');
        $this->form_validation->set_rules('sDesc', 'SDesc', 'required');
        $this->form_validation->set_rules('lDesc', 'LDesc', 'required');

        if($this->form_validation->run() == false)
        {
                $data                          = array();
                $data['all_featured_products'] = $this->web_model->get_all_featured_product();
                $data['all_new_products']      = $this->web_model->get_all_new_product();

                $data['title'] = 'Admin';
                $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

                $data2['title2'] = 'Add';
                $data2['hidden'] = 'hidden';

                $this->load->view('web/inc/sideA',$data);
                $this->load->view('web/inc/topA',$data);
                $this->load->view('web/pages/crudAdmin', $data2);
                $this->load->view('web/inc/bottom');

        }else{

            $config = [
                'upload_path' => './uploads/',
                'allowed_types' => 'gif|jpg|png'
            ];

            $this->load->library('upload');
            $this->upload->initialize($config);

            if ($this->upload->do_upload('userfile'))
            {
                $image = $this->upload->data('file_name');
            }else
            {
                $kosong = true;
            }

            $data = [
                'product_title' => htmlspecialchars($this->input->post('name', true)),
                'product_short_description' => htmlspecialchars($this->input->post('sDesc', true)),
                'product_long_description' => htmlspecialchars($this->input->post('lDesc', true))
            ];
            if(!$kosong)
            {
                $data += ['product_image' => $image];
            }
            $data += [
                'product_price' => htmlspecialchars($this->input->post('price', true)),
                'product_quantity' => htmlspecialchars($this->input->post('quantity', true)),
                'product_feature' => htmlspecialchars($this->input->post('feature', true)),
                'product_category' => htmlspecialchars($this->input->post('category', true))
            ];

            $this->db->set($data);
            $this->db->where('product_id', $this->input->post('id'));
            $this->db->update('tbl_product');   
            $this->session->set_flashdata('alert', '<div class="alert alert-success" role="alert"> Produk telah berhasil diupdate </div>');
            redirect('web/admin');
        }
    }

    public function delP($id)
    {
        $this->db->where('product_id', $id);
        $this->db->delete('tbl_product');
        $this->session->set_flashdata('alert', '<div class="alert alert-success" role="alert"> Produk berhasil dihapus </div>');
        redirect('web/admin');
    }
    
    
    public function orders()
    {
        $data                          = array();
        $data['all_featured_products'] = $this->web_model->get_all_featured_product();
        $data['all_new_products']      = $this->web_model->get_all_new_product();

        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user',['email' => $this->session->userdata('email')])->row_array();

        $data2['orders'] = $this->db->join('tbl_order_details', 'tbl_order_details.order_id = tbl_order.order_id')->get('tbl_order')->result_array();

        $this->load->view('web/inc/sideA',$data);
        $this->load->view('web/inc/topA',$data);
        $this->load->view('web/pages/ordersA', $data2);
        $this->load->view('web/inc/bottom');
    }

    public function accStatus()
    {
        $role = $this->input->post('role');
        $orderId = $this->input->post('orderId');
        $productId = $this->input->post('productId');
        $status = $this->input->post('status');

        $this->db->set('actions', $status);
        $this->db->where('order_id', $orderId);
        $this->db->update('tbl_order');

        if ($role == 1) {
            if ($status == "Selesai") {
                $this->db->query('UPDATE `tbl_product` SET `product_quantity` = `product_quantity` + 1 WHERE `product_id` = ' . $productId . ' AND `product_quantity` > 0');
            }
            $this->session->set_flashdata('alert', '<div class="alert alert-success" role="alert"> Telah berhasil update status order </div>');
            redirect('web/admin');
        } else if ($role == 2) {
            redirect('orders');
        }
    }

}
