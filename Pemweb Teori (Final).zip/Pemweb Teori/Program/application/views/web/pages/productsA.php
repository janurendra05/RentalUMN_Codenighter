<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<?=
                
                $this->session->flashdata('alert');
                    
                if(isset($_SESSION['alert'])){
                    unset($_SESSION['alert']);
                }
            ?> 
<h1 class="h3 mb-4 text-gray-800">Products</h1>

<table id="myTable" class="table table-striped table-bordered mw-100">
        <thead class="text-center">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Short Desc</th>
                <th>Long Desc</th>
                <th>Image</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Feature ID</th>
                <th>Category ID</th>
                <th><a class="btn btn-info" href="<?= base_url('web/addP'); ?>"><i class="fas fa-fw fa-plus"></i> Product</a></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($products as $p): ?>
            <tr class="text-center">
                <td><?= $p['product_id'] ?></td>
                <td><?= $p['product_title'] ?></td>
                <td><div class="long"><?= $p['product_short_description'] ?></div></td>
                <td><div class="long"><?= $p['product_long_description'] ?></div></td>
                <td><?= '<img src="'. base_url('uploads/').$p['product_image'] .'" class="img-thumbnail">' ?></td>
                <td><?= $p['product_price'] ?></td>
                <td><?= $p['product_quantity'] ?></td>
                <td><?= $p['product_feature'] ?></td>
                <td><?= $p['product_category'] ?></td>
                <td>
                    <a href="<?= base_url('web/editP/').$p['product_id']; ?>" class="mr-4"><i class="far fa-fw fa-edit"></i></a>
                    <a href="<?= base_url('web/delP/').$p['product_id']; ?>"><i class="far fa-fw fa-trash-alt"></i></a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot class="text-center">
            <tr>
            <th>ID</th>
                <th>Name</th>
                <th>Short Desc</th>
                <th>Long Desc</th>
                <th>Image</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Feature ID</th>
                <th>Category ID</th>
                <th></th>
            </tr>
        </tfoot>
    </table>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->