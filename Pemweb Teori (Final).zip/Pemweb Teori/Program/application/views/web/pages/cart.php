

<div class="main m-5">
    <div class="content">
        <div class="cartoption">		
            <div class="cartpage">
                <h2>Rental Cart</h2>
                <?php if ($this->cart->total_items()) { ?>
                    <table class="tblone table table-bordered">
                        <tr>
                            <th width="5%">NO.</th>
                            <th width="20%">Product Name</th>
                            <th width="10%">Image</th>
                            <th width="15%">Price</th>
                            <th width="25%">Duration (Hour)</th>
                            <th width="15%">Total Price</th>
                            <th width="5%">Remove</th>
                        </tr>
                        <?php
                        $i = 0;
                        foreach ($cart_contents as $cart_items) {
                            $i++;
                            ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $cart_items['name'] ?></td>
                                <td><img class="img-fluid img-thumbnail" src="<?php echo base_url('uploads/' . $cart_items['options']['product_image']) ?>" alt=""/></td>
                                <td>RP. <?php echo $this->cart->format_number($cart_items['price']) ?></td>
                                <td>
                                    <form action="<?php echo base_url('update/cart'); ?>" method="post">
                                        <div class="row">
                                            <div class="col">
                                                <input class="form-control" type="number" name="qty" value="<?php echo $cart_items['qty'] ?>"/>
                                            </div>
                                            <input type="hidden" name="rowid" value="<?php echo $cart_items['rowid'] ?>"/>
                                            <div class="col">
                                                <input class="btn btn-primary" type="submit" name="submit" value="Update"/>
                                            </div>
                                        </div>
                                    </form>
                                </td>
                                <td>RP. <?php echo $this->cart->format_number($cart_items['subtotal']) ?></td>
                                <td>
                                    <form action="<?php echo base_url('remove/cart'); ?>" method="post">
                                        <input type="hidden" name="rowid" value="<?php echo $cart_items['rowid'] ?>"/>
                                        <input class="btn btn-danger" type="submit" name="submit" value="X"/>
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>


                    </table>
                    <table style="float:right;text-align:left;" width="40%">
                        <tr>
                            <th>Sub Total : </th>
                            <td>RP. <?php echo $this->cart->format_number($this->cart->total()) ?></td>
                        </tr>
                        <tr>
                            <th>VAT : </th>
                            <td>RP. 
                                <?php
                                $total = $this->cart->total();
                                $tax = ($total * 15) / 100;
                                echo $this->cart->format_number($tax);
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Grand Total :</th>
                            <td>RP. <?php echo $this->cart->format_number($tax + $this->cart->total()); ?> </td>
                        </tr>
                    </table>
                    <?php
                } else {
                    echo "<h1>Your Cart Empty</h1>";
                }
                ?>
            </div>
            <div class="shopping">
                <div class="shopleft my-1">
                    <a class="btn btn-warning text-dark" href="<?php echo base_url('product') ?>">Continue Renting</a>
                </div>
                <div class="shopright my-1">
                    <?php
                    $customer_id = $user['id'];
                    if (empty($customer_id)) {
                        ?>
                        <a class="btn btn-info" href="<?php echo base_url('user_form') ?>">Checkout</a>
                        <?php
                    } elseif (!empty($customer_id)) {
                        ?>
                        <a class="btn btn-info" href = "<?php echo base_url('save/order') ?>">Checkout</a>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>  	
        <div class="clear"></div>
    </div>
</div>
