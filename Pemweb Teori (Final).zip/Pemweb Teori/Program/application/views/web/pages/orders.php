

<div class="main">
	<table id="example" class="table table-striped table-bordered" style="width:100%">  
            <thead class="text-center">
                <tr>
                    <th>Order ID</th>
                    <th>Metode Pembayaran</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody class="text-center">

            	<?php $arr_chunk_product = array_chunk($orderlist,12);?>
            	<?php foreach ($arr_chunk_product as $tmp){?>
            	<?php foreach ($tmp as $row){?>
					<tr>
					
					<td><?php echo $row->order_id ;?></td>
					<td><?php if($row->payment_id == 1)echo "Cash on Delivery"; ?></td>
					<td><?php echo $row->order_total; ?></td>
					<td><?php echo $row->actions; ?></td>
                    <td>
                        <form action="<?= base_url('web/accStatus'); ?>" method="post">
                            <input type="hidden" value="2" name="role"/>
                            <!-- <input type="hidden" value="<?= $row->product_id ?>" name="productId"> -->
                            <input type="hidden" value="<?= $row->order_id ?>" name="orderId"/>
                            <input type="hidden" value="Siap di-Pick-Up" name="status">
                            <?php if ($row->actions == "Sudah Dikirim"): ?>
                            <button type="submit" class="btn btn-primary">Return</button>
                            <?php endif; ?>
                        </form>
                    </td>
					</tr>
				 <?php } ?><?php } ?>

            </tbody>
            <tfoot class="text-center">
                <tr>
                    <th>Order ID</th>
                    <th>Metode Pembayaran</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </div>
    