

<div class="container" style="text-align: center;">
    <h1 style="color: red;">Pesanan Berhasil !!!</h1><br>
    <h2 style="color: green;">Metode Cash on Delivery</h2><br><br>
    <h2 style="color: yellow;">Kurir akan segera mengantar pesanan anda !</h2><br>
    
</div>

                <center><div class="shopping">
                <div class="shopleft">
                    <a href="<?php echo base_url('web/user') ?>"> <img src="<?php echo base_url() ?>assets/web/images/shop.png" alt="" /></a>
                </div></center>