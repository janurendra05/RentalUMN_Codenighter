<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800"><?= $title2 ?></h1>

<div class="row">
  <div class="col-md-6 offset-md-3">
    <?= form_open_multipart('web/addedP'); ?>
        <div class="form-group">
            <input type="text" class="form-control w-25" id="id" value="ID            " disabled>
        </div>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?= set_value('name'); ?>">
            <?= form_error('name','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" class="form-control" id="price" name="price" placeholder="Price" value="<?= set_value('price'); ?>">
            <?= form_error('price','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity</label>
            <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Quantity" value="<?= set_value('quantity'); ?>">
            <?= form_error('quantity','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="feature">Feature</label>
            <input type="text" class="form-control" id="feature" name="feature" placeholder="Feature" value="<?= set_value('feature'); ?>">
            <?= form_error('feature','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="category">Category</label>
            <input type="text" class="form-control" id="category" name="category" placeholder="Category" value="<?= set_value('category'); ?>">
            <?= form_error('category','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="sDesc">Short Desc</label>
            <textarea class="form-control" id="sDesc" rows="2" name="sDesc" placeholder="Short Desc"><?= set_value('sDesc'); ?></textarea>
            <?= form_error('sDesc','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="lDesc">Long Desc</label>
            <textarea class="form-control" id="lDesc" rows="3" name="lDesc" placeholder="Long Desc"><?= set_value('lDesc'); ?></textarea>
            <?= form_error('lDesc','<small class="text-danger pl-3">','</small>'); ?>
        </div>
        <div class="form-group">
            <label for="image">Choose Image</label>
            <input type="file" class="form-control-file" id="image" name="userfile">
        </div>
        <button type="submit" class="btn btn-primary mb-4 mt-3">Submit</button>
        <a class="btn btn-secondary mb-4 mt-3" href="<?= base_url('web/admin'); ?>">Cancel</a>
    <?= form_close(); ?>
  </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->