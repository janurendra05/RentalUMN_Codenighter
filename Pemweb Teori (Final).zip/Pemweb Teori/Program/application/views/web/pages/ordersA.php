<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Orders</h1>

<table id="myTable" class="table table-striped table-bordered" style="width:100%">
        <thead class="text-center">
            <tr>
                <th>Order ID</th>
                <th>Customer ID</th>
                <th>Payment</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($orders as $o): ?>
            <tr class="text-center">
                <td style="padding-top: 35px;"><?= $o['order_id'] ?></td>
                <td style="padding-top: 35px;"><?= $o['customer_id'] ?></td>
                <td style="padding-top: 35px;">Cash On Delivery</td>
                <td style="padding-top: 35px;"><?= $o['order_total'] ?></td>
                <td>
                    <form action="<?= base_url('web/accStatus'); ?>" method="post">
                        <div class="form-group">
                            <input type="hidden" class="form-control" value="<?= $o['order_id'] ?>" name="orderId">
                        </div>

                        <div class="form-group">
                            <input type="hidden" class="form-control" value="1" name="role"/>
                        </div>

                        <div class="form-group">
                            <input type="hidden" value="<?= $o['product_id'] ?>" name="productId">
                        </div>

                        <div class="row d-flex justify-content-center">

                            <?php if ($o['actions'] != "Selesai"): ?>
                                <div class="col pr-0">
                                    <div class="form-group">
                                        <select class="form-control" id="exampleFormControlSelect1" name="status">
                                        <option><?= $o['actions'] ?></option>
                                        <option disabled>______________</option>
                                        <option>Sedang Dikirim</option>
                                        <option>Sudah Dikirim</option>
                                        <option>Siap di Pick-up</option>
                                        <option>Selesai</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col px-0">
                                    <button type="submit" class="btn btn-primary">Confirm</button>
                                </div>
                            <?php else: ?>
                                <?= $o['actions'] ?>
                            <?php endif; ?>

                        </div>
                    </form>

                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot class="text-center">
            <tr>
                <th>Order ID</th>
                <th>Customer ID</th>
                <th>Payment</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </tfoot>
    </table>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->